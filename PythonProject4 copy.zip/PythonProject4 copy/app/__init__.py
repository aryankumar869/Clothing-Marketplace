from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from .config import Config
from datetime import timedelta
from .utils.sqlite_schema import ensure_sqlite_schema

db = SQLAlchemy()
jwt = JWTManager()


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    jwt.init_app(app)

    # Ensure SQLite schema updates (no-migrations project)
    with app.app_context():
        db.create_all()
        ensure_sqlite_schema(db)

    # Enforce strong secrets in production
    if app.config.get('ENV') == 'production':
        if not app.config.get('SECRET_KEY') or 'change-me' in app.config.get('SECRET_KEY', ''):
            raise RuntimeError('SECRET_KEY must be set to a strong value in production')
        if not app.config.get('JWT_SECRET_KEY') or 'change-me' in app.config.get('JWT_SECRET_KEY', ''):
            raise RuntimeError('JWT_SECRET_KEY must be set to a strong value in production')

    # JWT expiration
    exp_minutes = int(app.config.get('JWT_ACCESS_TOKEN_EXPIRES_MINUTES', 60))
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(minutes=exp_minutes)

    # CORS: restrict if origins configured, else allow none (same-origin)
    cors_origins = app.config.get('CORS_ORIGINS') or []
    if cors_origins:
        CORS(app, resources={r"/api/*": {"origins": cors_origins}})
    else:
        CORS(app, resources={r"/api/*": {"origins": []}})

    # Security headers
    @app.after_request
    def add_security_headers(resp):
        resp.headers.setdefault('X-Content-Type-Options', 'nosniff')
        resp.headers.setdefault('X-Frame-Options', 'DENY')
        resp.headers.setdefault('Referrer-Policy', 'strict-origin-when-cross-origin')
        resp.headers.setdefault('Permissions-Policy', 'geolocation=(), microphone=(), camera=()')
        # Basic CSP (keep permissive enough for current UI)
        resp.headers.setdefault(
            'Content-Security-Policy',
            "default-src 'self'; "
            "img-src 'self' data:; "
            "style-src 'self' https://fonts.googleapis.com 'unsafe-inline'; "
            "font-src 'self' https://fonts.gstatic.com; "
            "script-src 'self' https://maps.googleapis.com 'unsafe-inline'; "
            "connect-src 'self'; "
            "frame-ancestors 'none';"
        )
        return resp

    from .routes import auth_bp, shopkeeper_bp, customer_bp
    from .routes.web import web_bp
    from .routes.admin import admin_bp
    app.register_blueprint(web_bp)
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(admin_bp, url_prefix='/api/admin')
    app.register_blueprint(shopkeeper_bp, url_prefix='/api/shopkeeper')
    app.register_blueprint(customer_bp, url_prefix='/api/customer')

    from .utils.error_handlers import register_error_handlers
    register_error_handlers(app)

    return app
