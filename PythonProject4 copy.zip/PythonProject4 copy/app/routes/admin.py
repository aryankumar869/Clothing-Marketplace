from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models import User, LoginAttempt

admin_bp = Blueprint('admin', __name__)


def _is_admin():
    """Current user admin hai ya nahi (SQLite se check)."""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    return user and getattr(user, 'role', None) == 'admin'


@admin_bp.route('/data', methods=['GET'])
@jwt_required()
def get_all_data():
    """Customer/Shopkeeper ka sara data — sirf admin dekh sakta hai."""
    if not _is_admin():
        return jsonify({'error': 'Sirf admin ye data dekh sakta hai.'}), 403
    users = User.query.order_by(User.id).all()
    attempts = LoginAttempt.query.order_by(LoginAttempt.attempted_at.desc()).limit(500).all()
    return jsonify({
        'users': [
            {'id': u.id, 'name': u.name, 'email': u.email, 'role': u.role,
             'created_at': u.created_at.isoformat() if u.created_at else None}
            for u in users
        ],
        'attempts': [
            {'id': a.id, 'email': a.email, 'success': a.success,
             'attempted_at': a.attempted_at.isoformat() if a.attempted_at else None}
            for a in attempts
        ]
    }), 200
