from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.controllers.auth_controller import register_user, login_user, get_login_history
from app.utils.rate_limit import rate_limiter

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/register', methods=['POST'])
def register():
    ip = request.headers.get('X-Forwarded-For', request.remote_addr) or 'unknown'
    if not rate_limiter.allow(f"register:{ip}", limit=10, window_seconds=60):
        return jsonify({'error': 'Too many requests. Please try again later.'}), 429
    data = request.get_json()
    return register_user(data)


@auth_bp.route('/login', methods=['POST'])
def login():
    ip = request.headers.get('X-Forwarded-For', request.remote_addr) or 'unknown'
    if not rate_limiter.allow(f"login:{ip}", limit=15, window_seconds=60):
        return jsonify({'error': 'Too many login attempts. Please try again later.'}), 429
    data = request.get_json(silent=True)
    if not data and request.form:
        data = {'email': request.form.get('email'), 'password': request.form.get('password')}
    return login_user(data or {})


@auth_bp.route('/login-history', methods=['GET'])
@jwt_required()
def login_history():
    return get_login_history()