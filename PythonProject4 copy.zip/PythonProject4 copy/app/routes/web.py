from flask import Blueprint, render_template, current_app

web_bp = Blueprint('web', __name__)


@web_bp.route('/')
def index():
    google_api_key = current_app.config.get('GOOGLE_API_KEY')
    return render_template('index.html', google_api_key=google_api_key)


@web_bp.route('/login')
def login():
    return render_template('login.html')


@web_bp.route('/register')
def register():
    return render_template('register.html')


@web_bp.route('/shopkeeper')
def shopkeeper_page():
    """Simple UI for shopkeepers to upload products."""
    return render_template('shopkeeper.html')


@web_bp.route('/customer')
def customer_page():
    """Simple UI for customers to browse products."""
    return render_template('customer.html')


@web_bp.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')


@web_bp.route('/login-history')
def login_history_page():
    return render_template('login_history.html')


@web_bp.route('/data')
def sqlite_data():
    """Data page — sirf admin ko data dikhega (page load pe API se check)."""
    return render_template('data.html')
