from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.controllers.customer_controller import (
    browse_shops, browse_products, place_order, get_order_status,
    create_rental, return_rental
)

customer_bp = Blueprint('customer', __name__)

@customer_bp.route('/shops', methods=['GET'])
@jwt_required()
def get_shops():
    return browse_shops()

@customer_bp.route('/products', methods=['GET'])
@jwt_required()
def get_products():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    return browse_products(page, per_page)

@customer_bp.route('/order', methods=['POST'])
@jwt_required()
def create_order():
    user_id = get_jwt_identity()
    data = request.get_json()
    return place_order(user_id, data)

@customer_bp.route('/orders', methods=['GET'])
@jwt_required()
def get_orders():
    user_id = get_jwt_identity()
    return get_order_status(user_id)


@customer_bp.route('/rent', methods=['POST'])
@jwt_required()
def create_rent():
    user_id = get_jwt_identity()
    data = request.get_json()
    return create_rental(user_id, data)


@customer_bp.route('/rent/<int:rental_id>/return', methods=['POST'])
@jwt_required()
def mark_rental_returned(rental_id):
    user_id = get_jwt_identity()
    return return_rental(user_id, rental_id)