from .auth import auth_bp
from .shopkeeper import shopkeeper_bp
from .customer import customer_bp
