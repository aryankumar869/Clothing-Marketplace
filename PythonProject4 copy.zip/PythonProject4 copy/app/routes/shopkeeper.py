from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.controllers.shopkeeper_controller import (
    create_shop_profile, add_product, edit_product, delete_product,
    get_orders, update_order_status
)

shopkeeper_bp = Blueprint('shopkeeper', __name__)

@shopkeeper_bp.route('/shop', methods=['POST'])
@jwt_required()
def create_shop():
    user_id = get_jwt_identity()
    data = request.get_json()
    return create_shop_profile(user_id, data)

@shopkeeper_bp.route('/product', methods=['POST'])
@jwt_required()
def upload_product():
    user_id = get_jwt_identity()
    # Convert form data to a plain dict so validation works correctly
    data = request.form.to_dict()
    file = request.files.get('image')
    return add_product(user_id, data, file)

@shopkeeper_bp.route('/product/<int:product_id>', methods=['PUT'])
@jwt_required()
def update_product(product_id):
    user_id = get_jwt_identity()
    data = request.get_json()
    return edit_product(user_id, product_id, data)

@shopkeeper_bp.route('/product/<int:product_id>', methods=['DELETE'])
@jwt_required()
def remove_product(product_id):
    user_id = get_jwt_identity()
    return delete_product(user_id, product_id)

@shopkeeper_bp.route('/orders', methods=['GET'])
@jwt_required()
def get_shop_orders():
    user_id = get_jwt_identity()
    return get_orders(user_id)

@shopkeeper_bp.route('/order/<int:order_id>/status', methods=['PUT'])
@jwt_required()
def update_status(order_id):
    user_id = get_jwt_identity()
    data = request.get_json()
    return update_order_status(user_id, order_id, data)
