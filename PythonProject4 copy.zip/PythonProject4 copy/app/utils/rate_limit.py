import time
from collections import defaultdict, deque


class SimpleRateLimiter:
    """
    Very small in-memory rate limiter.
    Not perfect for multi-server setups, but good baseline security for one server.
    """

    def __init__(self):
        self._hits = defaultdict(lambda: deque())

    def allow(self, key: str, limit: int, window_seconds: int) -> bool:
        now = time.time()
        q = self._hits[key]
        # drop old hits
        cutoff = now - window_seconds
        while q and q[0] < cutoff:
            q.popleft()
        if len(q) >= limit:
            return False
        q.append(now)
        return True


rate_limiter = SimpleRateLimiter()

