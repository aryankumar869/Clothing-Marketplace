from flask_jwt_extended import jwt_required

def role_required(role):
    def decorator(func):
        @jwt_required()
        def wrapper(*args, **kwargs):
            from flask_jwt_extended import get_jwt_identity
            user = get_jwt_identity()
            if user['role'] != role:
                return {'error': 'Unauthorized'}, 403
            return func(*args, **kwargs)
        return wrapper
    return decorator