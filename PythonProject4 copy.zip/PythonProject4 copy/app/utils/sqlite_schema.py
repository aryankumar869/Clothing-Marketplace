"""
SQLite schema helper.

This project uses db.create_all() (no migrations). When we add new columns/tables,
existing SQLite databases won't automatically update. This module applies minimal
ALTER TABLE / CREATE TABLE statements safely (idempotent).
"""

from sqlalchemy import text


def ensure_sqlite_schema(db):
    """Apply minimal schema updates for SQLite if needed."""
    engine = db.get_engine()
    if engine.dialect.name != "sqlite":
        return

    with engine.begin() as conn:
        # ---- products table: add rental fields if missing ----
        cols = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        existing = {row[1] for row in cols}  # (cid, name, type, notnull, dflt_value, pk)

        if "is_rentable" not in existing:
            conn.execute(text("ALTER TABLE products ADD COLUMN is_rentable BOOLEAN DEFAULT 0"))
        if "rent_price_per_day" not in existing:
            conn.execute(text("ALTER TABLE products ADD COLUMN rent_price_per_day NUMERIC(10,2)"))

        # ---- rentals table: create if missing ----
        conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS rentals (
                    id INTEGER PRIMARY KEY,
                    customer_id INTEGER NOT NULL,
                    product_id INTEGER NOT NULL,
                    shop_id INTEGER NOT NULL,
                    start_date DATE NOT NULL,
                    end_date DATE NOT NULL,
                    daily_rate NUMERIC(10,2) NOT NULL,
                    total_rent NUMERIC(10,2) NOT NULL,
                    auto_pay_enabled BOOLEAN DEFAULT 1,
                    late_fee_per_day NUMERIC(10,2) DEFAULT 0,
                    returned_at DATE,
                    late_days INTEGER DEFAULT 0,
                    late_fee_total NUMERIC(10,2) DEFAULT 0,
                    final_amount_charged NUMERIC(10,2),
                    status VARCHAR(20) DEFAULT 'active',
                    created_at DATETIME
                )
                """
            )
        )

