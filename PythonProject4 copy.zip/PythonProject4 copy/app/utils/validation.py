import re


def validate_registration(data):
    errors = []
    if not data or not isinstance(data, dict):
        return ['Invalid data']
    if not data.get('name') or len(data['name']) < 2:
        errors.append('Name must be at least 2 characters')
    if not re.match(r'^[^@]+@[^@]+\.[^@]+$', data.get('email', '')):
        errors.append('Invalid email')
    if not data.get('password') or len(data['password']) < 6:
        errors.append('Password must be at least 6 characters')
    if data.get('role') not in ('shopkeeper', 'customer'):
        errors.append('Role must be shopkeeper or customer')
    return errors


def validate_login(data):
    errors = []
    if not data or not isinstance(data, dict):
        return ['Invalid data']
    if not data.get('email'):
        errors.append('Email is required')
    if not data.get('password'):
        errors.append('Password is required')
    return errors


def validate_shop_profile(data):
    errors = []
    if not data or not isinstance(data, dict):
        return ['Invalid data']
    if not data.get('shop_name') or len(data['shop_name']) < 2:
        errors.append('Shop name must be at least 2 characters')
    if not data.get('address') or len(data['address']) < 5:
        errors.append('Address must be at least 5 characters')
    return errors


def validate_product(data):
    errors = []
    if not data or not isinstance(data, dict):
        return ['Invalid data']
    try:
        price = float(data.get('price', 0))
        if price <= 0:
            errors.append('Price must be greater than 0')
    except (TypeError, ValueError):
        errors.append('Invalid price')
    if data.get('stock') is not None:
        try:
            stock = int(data.get('stock'))
            if stock < 0:
                errors.append('Stock cannot be negative')
        except (TypeError, ValueError):
            errors.append('Invalid stock')
    return errors


def validate_order(data):
    errors = []
    if not data or not isinstance(data, dict):
        return ['Invalid data']
    if not data.get('items') or not isinstance(data['items'], list):
        errors.append('Items must be a non-empty list')
    elif data['items']:
        for item in data['items']:
            if not isinstance(item, dict) or 'product_id' not in item or 'quantity' not in item:
                errors.append('Each item must have product_id and quantity')
                break
            if int(item.get('quantity', 0)) <= 0:
                errors.append('Quantity must be positive')
                break
    if not data.get('shop_id'):
        errors.append('shop_id is required')
    if not data.get('delivery_address') or len(str(data['delivery_address']).strip()) < 5:
        errors.append('Delivery address must be at least 5 characters')
    return errors
