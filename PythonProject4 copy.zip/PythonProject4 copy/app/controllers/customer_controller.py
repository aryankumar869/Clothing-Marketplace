from flask import jsonify
from datetime import date, timedelta
from app.services.order_service import place_order_service, get_customer_orders_service
from app.models import Shop, Product, Rental
from app.utils.validation import validate_order

def browse_shops():
    shops = Shop.query.all()
    return jsonify([{'id': s.id, 'name': s.shop_name, 'address': s.address} for s in shops]), 200

def browse_products(page, per_page):
    products = Product.query.paginate(page=page, per_page=per_page)
    return jsonify({
        'products': [{
            'id': p.id,
            'shop_id': p.shop_id,
            'image_url': p.image_url,
            'price': str(p.price),
            'description': p.description,
            'stock': p.stock,
            'size': p.size,
            'color': p.color,
            'is_rentable': p.is_rentable,
            'rent_price_per_day': str(p.rent_price_per_day) if p.rent_price_per_day is not None else None
        } for p in products.items],
        'total': products.total,
        'pages': products.pages
    }), 200

def place_order(user_id, data):
    errors = validate_order(data)
    if errors:
        return jsonify({'errors': errors}), 400
    return place_order_service(user_id, data)

def get_order_status(user_id):
    return get_customer_orders_service(user_id)


def create_rental(user_id, data):
    """
    Create a rental based on per-day rate.
    duration_type: 'week', 'month', 'custom'
    duration_value: number of weeks/months/days
    """
    errors = []
    product_id = data.get('product_id')
    duration_type = data.get('duration_type')
    duration_value = data.get('duration_value')
    late_fee_per_day = data.get('late_fee_per_day', 0)

    try:
        duration_value = int(duration_value)
        if duration_value <= 0:
            errors.append('Duration must be positive')
    except (TypeError, ValueError):
        errors.append('Invalid duration')

    if duration_type not in ('week', 'month', 'custom'):
        errors.append('Invalid duration type')

    if not product_id:
        errors.append('product_id is required')

    if errors:
        return jsonify({'errors': errors}), 400

    product = Product.query.get(product_id)
    if not product or not product.is_rentable or not product.rent_price_per_day:
        return jsonify({'error': 'Product is not available for rent'}), 400

    # Calculate number of days
    if duration_type == 'week':
        days = duration_value * 7
    elif duration_type == 'month':
        days = duration_value * 30
    else:
        days = duration_value

    start = date.today()
    end = start + timedelta(days=days)

    daily_rate = product.rent_price_per_day
    total_rent = daily_rate * days

    rental = Rental(
        customer_id=user_id,
        product_id=product.id,
        shop_id=product.shop_id,
        start_date=start,
        end_date=end,
        daily_rate=daily_rate,
        total_rent=total_rent,
        auto_pay_enabled=True,
        late_fee_per_day=late_fee_per_day or 0
    )
    from app import db
    db.session.add(rental)
    db.session.commit()

    return jsonify({
        'message': 'Rental created with auto-payment enabled. Late fees will be applied automatically if returned late.',
        'rental': {
            'id': rental.id,
            'product_id': rental.product_id,
            'start_date': str(rental.start_date),
            'end_date': str(rental.end_date),
            'daily_rate': str(rental.daily_rate),
            'total_rent': str(rental.total_rent),
            'late_fee_per_day': str(rental.late_fee_per_day)
        }
    }), 201


def return_rental(user_id, rental_id):
    """Mark rental as returned and auto-calculate late fee."""
    rental = Rental.query.filter_by(id=rental_id, customer_id=user_id).first()
    if not rental:
        return jsonify({'error': 'Rental not found'}), 404
    if rental.status == 'returned':
        return jsonify({'message': 'Rental already returned'}), 200

    today = date.today()
    rental.returned_at = today

    if today > rental.end_date:
        delta_days = (today - rental.end_date).days
        rental.late_days = delta_days
        rental.late_fee_total = (rental.late_fee_per_day or 0) * delta_days
    else:
        rental.late_days = 0
        rental.late_fee_total = 0

    rental.final_amount_charged = rental.total_rent + (rental.late_fee_total or 0)
    rental.status = 'returned'

    from app import db
    db.session.commit()

    return jsonify({
        'message': 'Rental returned. Auto-payment simulated.',
        'late_days': rental.late_days,
        'late_fee_total': str(rental.late_fee_total),
        'final_amount_charged': str(rental.final_amount_charged)
    }), 200