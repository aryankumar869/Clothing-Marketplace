from flask import jsonify
from app.services.image_service import upload_image
from app.services.order_service import get_shop_orders_service, update_order_status_service
from app.models import Shop, Product
from app import db
from app.utils.validation import validate_shop_profile, validate_product


def create_shop_profile(user_id, data):
    errors = validate_shop_profile(data)
    if errors:
        return jsonify({'errors': errors}), 400

    shop = Shop(owner_id=user_id, **data)
    db.session.add(shop)
    db.session.commit()
    return jsonify({'message': 'Shop created successfully'}), 201


def add_product(user_id, data, file):
    errors = validate_product(data)
    if errors:
        return jsonify({'errors': errors}), 400

    shop = Shop.query.filter_by(owner_id=user_id).first()
    if not shop:
        return jsonify({'error': 'Shop not found'}), 404

    image_url = None
    if file:
        image_url = upload_image(file)

    # Normalize rental fields
    is_rentable = str(data.get('is_rentable', '')).lower() in ('1', 'true', 'yes', 'on')
    rent_price_per_day = data.get('rent_price_per_day')
    product_kwargs = {
        'shop_id': shop.id,
        'image_url': image_url,
        'price': data.get('price'),
        'description': data.get('description'),
        'stock': data.get('stock'),
        'size': data.get('size'),
        'color': data.get('color'),
        'is_rentable': is_rentable,
        'rent_price_per_day': rent_price_per_day if is_rentable and rent_price_per_day else None,
    }

    product = Product(**product_kwargs)
    db.session.add(product)
    db.session.commit()
    return jsonify({'message': 'Product added successfully'}), 201


def edit_product(user_id, product_id, data):
    product = Product.query.join(Shop).filter(Product.id == product_id, Shop.owner_id == user_id).first()
    if not product:
        return jsonify({'error': 'Product not found'}), 404

    for key, value in data.items():
        setattr(product, key, value)
    db.session.commit()
    return jsonify({'message': 'Product updated successfully'}), 200


def delete_product(user_id, product_id):
    product = Product.query.join(Shop).filter(Product.id == product_id, Shop.owner_id == user_id).first()
    if not product:
        return jsonify({'error': 'Product not found'}), 404

    db.session.delete(product)
    db.session.commit()
    return jsonify({'message': 'Product deleted successfully'}), 200


def get_orders(user_id):
    return get_shop_orders_service(user_id)


def update_order_status(user_id, order_id, data):
    return update_order_status_service(user_id, order_id, data)