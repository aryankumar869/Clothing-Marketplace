from flask import jsonify
from flask_jwt_extended import get_jwt_identity
from app.services.auth_service import register_user_service, login_user_service, get_login_history_service
from app.utils.validation import validate_registration, validate_login

def register_user(data):
    errors = validate_registration(data)
    if errors:
        return jsonify({'errors': errors}), 400
    return register_user_service(data)

def login_user(data):
    if not data:
        return jsonify({'error': 'Email aur password bhejein.'}), 400
    errors = validate_login(data)
    if errors:
        return jsonify({'error': errors[0] if errors else 'Invalid data'}), 400
    return login_user_service(data)

def get_login_history():
    return get_login_history_service(get_jwt_identity())