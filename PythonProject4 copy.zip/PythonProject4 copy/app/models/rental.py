from app import db
from datetime import datetime, date


class Rental(db.Model):
    __tablename__ = 'rentals'
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    shop_id = db.Column(db.Integer, db.ForeignKey('shops.id'), nullable=False)

    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    daily_rate = db.Column(db.Numeric(10, 2), nullable=False)
    total_rent = db.Column(db.Numeric(10, 2), nullable=False)

    # Auto-pay + late fee simulation
    auto_pay_enabled = db.Column(db.Boolean, default=True)
    late_fee_per_day = db.Column(db.Numeric(10, 2), default=0)
    returned_at = db.Column(db.Date)
    late_days = db.Column(db.Integer, default=0)
    late_fee_total = db.Column(db.Numeric(10, 2), default=0)
    final_amount_charged = db.Column(db.Numeric(10, 2))

    status = db.Column(db.String(20), default='active')  # active, returned, cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

