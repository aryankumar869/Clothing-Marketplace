from app import db
from datetime import datetime


class Product(db.Model):
    __tablename__ = 'products'
    id = db.Column(db.Integer, primary_key=True)
    shop_id = db.Column(db.Integer, db.ForeignKey('shops.id'), nullable=False)
    image_url = db.Column(db.String(255))
    price = db.Column(db.Numeric(10, 2), nullable=False)
    description = db.Column(db.Text)
    stock = db.Column(db.Integer, default=0)
    size = db.Column(db.String(10))
    color = db.Column(db.String(50))
    # Rental options
    is_rentable = db.Column(db.Boolean, default=False)
    rent_price_per_day = db.Column(db.Numeric(10, 2))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    order_items = db.relationship('OrderItem', backref='product', lazy=True)