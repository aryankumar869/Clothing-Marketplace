from app import db
from datetime import datetime


class LoginAttempt(db.Model):
    """SQLite mein har login try ka record - details dekhne ke liye."""
    __tablename__ = 'login_attempts'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), nullable=False)
    success = db.Column(db.Boolean, nullable=False)  # True = success, False = fail
    attempted_at = db.Column(db.DateTime, default=datetime.utcnow)
