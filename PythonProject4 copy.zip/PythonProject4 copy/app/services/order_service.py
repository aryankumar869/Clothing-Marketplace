from flask import jsonify
from app.models import Order, OrderItem, Product, Shop
from app import db


def place_order_service(user_id, data):
    total_price = 0
    order_items = []
    for item in data['items']:
        product = Product.query.get(item['product_id'])
        if not product or product.stock < item['quantity']:
            return jsonify({'error': 'Insufficient stock'}), 400
        total_price += product.price * item['quantity']
        order_items.append(OrderItem(product_id=item['product_id'], quantity=item['quantity'], price=product.price))
        product.stock -= item['quantity']

    order = Order(customer_id=user_id, shop_id=data['shop_id'], total_price=total_price,
                  delivery_address=data['delivery_address'])
    db.session.add(order)
    db.session.commit()
    for item in order_items:
        item.order_id = order.id
        db.session.add(item)
    db.session.commit()
    return jsonify({'message': 'Order placed successfully', 'order_id': order.id}), 201


def get_customer_orders_service(user_id):
    orders = Order.query.filter_by(customer_id=user_id).all()
    return jsonify([
        {
            'id': o.id,
            'shop_id': o.shop_id,
            'status': o.status,
            'total_price': str(o.total_price),
            'delivery_address': o.delivery_address,
            'created_at': o.created_at.isoformat() if o.created_at else None
        }
        for o in orders
    ]), 200


def get_shop_orders_service(user_id):
    orders = Order.query.join(Shop).filter(Shop.owner_id == user_id).all()
    return jsonify([
        {
            'id': o.id,
            'customer_id': o.customer_id,
            'shop_id': o.shop_id,
            'status': o.status,
            'total_price': str(o.total_price),
            'delivery_address': o.delivery_address,
            'created_at': o.created_at.isoformat() if o.created_at else None
        }
        for o in orders
    ]), 200


def update_order_status_service(user_id, order_id, data):
    order = Order.query.join(Shop).filter(Order.id == order_id, Shop.owner_id == user_id).first()
    if not order:
        return jsonify({'error': 'Order not found'}), 404
    status = data.get('status')
    if status:
        order.status = status
        db.session.commit()
    return jsonify({'message': 'Order status updated', 'order_id': order.id}), 200