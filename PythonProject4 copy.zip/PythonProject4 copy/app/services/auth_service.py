import bcrypt
from flask import jsonify
from flask_jwt_extended import create_access_token
from app.models import User, LoginAttempt
from app import db


def _save_login_attempt(email, success):
    """Har login try SQLite mein save - details baad mein dekhne ke liye."""
    try:
        attempt = LoginAttempt(email=email, success=success)
        db.session.add(attempt)
        db.session.commit()
    except Exception:
        db.session.rollback()


def register_user_service(data):
    email = (data.get('email') or '').strip().lower()
    hashed = bcrypt.hashpw(data['password'].encode('utf-8'), bcrypt.gensalt())
    user = User(name=data.get('name', '').strip(), email=email, password_hash=hashed.decode('utf-8'), role=data.get('role', 'customer'))
    db.session.add(user)
    db.session.commit()
    return jsonify({'message': 'User registered successfully'}), 201


def login_user_service(data):
    if not data:
        return jsonify({'error': 'Email aur password bhejein.'}), 400
    email = (data.get('email') or '').strip().lower()
    password = data.get('password') or ''
    if not email or not password:
        return jsonify({'error': 'Email aur password dono zaroori hain.'}), 400

    # Email case-insensitive - naye users lowercase, purane bhi match ho jayein
    user = User.query.filter_by(email=email).first()
    if not user:
        from sqlalchemy import func
        user = User.query.filter(func.lower(User.email) == email).first()
    if not user:
        _save_login_attempt(email, success=False)
        return jsonify({'error': 'Is email se koi account nahi mila. Pehle Register karein.'}), 401

    # Password check - SQLite se hash string aata hai
    try:
        pwd_bytes = password.encode('utf-8')
        stored = user.password_hash
        hash_bytes = stored.encode('utf-8') if isinstance(stored, str) else stored
        if not bcrypt.checkpw(pwd_bytes, hash_bytes):
            _save_login_attempt(email, success=False)
            return jsonify({'error': 'Galat password. Dobara try karein.'}), 401
    except Exception:
        _save_login_attempt(email, success=False)
        return jsonify({'error': 'Login check fail. Dobara try karein.'}), 401

    _save_login_attempt(email, success=True)
    token = create_access_token(identity=user.id)
    return jsonify({'token': token, 'role': user.role}), 200


def get_login_history_service(user_id):
    """Current user ke email se SQLite mein saved login attempts return karein."""
    from app.models import User
    user = User.query.get(user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404
    attempts = LoginAttempt.query.filter_by(email=user.email).order_by(LoginAttempt.attempted_at.desc()).limit(50).all()
    return jsonify({
        'email': user.email,
        'attempts': [
            {'id': a.id, 'success': a.success, 'attempted_at': a.attempted_at.isoformat() if a.attempted_at else None}
            for a in attempts
        ]
    }), 200
