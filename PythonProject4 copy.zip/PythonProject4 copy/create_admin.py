#!/usr/bin/env python3
"""
Kisi bhi registered user ko admin bana de (SQLite DB mein role update).
Usage: python create_admin.py <email>
Example: python create_admin.py admin@example.com
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app, db
from app.models import User


def main():
    if len(sys.argv) < 2:
        print("Usage: python create_admin.py <email>")
        print("Example: python create_admin.py admin@example.com")
        sys.exit(1)
    email = sys.argv[1].strip().lower()
    app = create_app()
    with app.app_context():
        user = User.query.filter_by(email=email).first()
        if not user:
            print("Error: Is email se koi user nahi mila. Pehle register karein:", email)
            sys.exit(1)
        user.role = 'admin'
        db.session.commit()
        print("Done. Ab", email, "admin hai. Is account se login karke /data pe jao.")


if __name__ == '__main__':
    main()
