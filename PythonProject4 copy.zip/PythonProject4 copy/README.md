# Clothing Marketplace API

Flask-based API for shopkeepers and customers (auth, shops, products, orders).

## Setup

```bash
cd /Users/aryankumar/PycharmProjects/PythonProject4
pip install -r requirements.txt
```

## Run on Web

```bash
python run.py
```

- **Local:** http://127.0.0.1:5050  
- **Network:** http://YOUR_IP:5050  

DB tables auto-create on first run (SQLite by default: `clothing_marketplace.db`).

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register (name, email, password, role: shopkeeper/customer) |
| POST | `/api/auth/login` | Login → returns JWT token |
| POST | `/api/shopkeeper/shop` | Create shop (JWT) |
| POST | `/api/shopkeeper/product` | Add product (JWT, form + image) |
| PUT | `/api/shopkeeper/product/<id>` | Update product (JWT) |
| DELETE | `/api/shopkeeper/product/<id>` | Delete product (JWT) |
| GET | `/api/shopkeeper/orders` | List shop orders (JWT) |
| PUT | `/api/shopkeeper/order/<id>/status` | Update order status (JWT) |
| GET | `/api/customer/shops` | List shops (JWT) |
| GET | `/api/customer/products` | List products (JWT) |
| POST | `/api/customer/order` | Place order (JWT) |
| GET | `/api/customer/orders` | My orders (JWT) |

Protected routes need header: `Authorization: Bearer <token>`.

## Admin — SQLite data sirf admin ko

Customer/Shopkeeper ka sara data (users + login attempts) **sirf admin** dekh sakta hai.

1. **Admin kaise banayein** (SQLite DB mein role update):
   ```bash
   python create_admin.py <email>
   ```
   Example: pehle koi user register karein (e.g. `you@example.com`), phir:
   ```bash
   python create_admin.py you@example.com
   ```
2. Usi account se **login** karein → Dashboard pe **"SQLite sara data dekhein (Admin)"** link dikhega.
3. **/data** page pe jao → Users + Login attempts ka sara data SQLite se dikhega. Non-admin ko "Sirf admin ye data dekh sakta hai" dikhega.

DB file: `clothing_marketplace.db` (project folder mein, sirf aapke Mac pe).
